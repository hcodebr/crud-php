<?php require("inc/header.php");?>
  <div class="wrapper">
    <?php
    require_once("inc/navbar.php");
    require_once("inc/sidebar.php");
    ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
    <?php require_once("inc/page-header.php");?>

      <!-- Main content -->
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Eventos Cadastrados</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Et, consequuntur. Nemo, itaque. Veniam, aspernatur? Aliquam, culpa repudiandae distinctio repellendus hic ducimus eaque error eum. Commodi voluptatibus ad iusto amet veniam?
              </div>
              <!-- /.card-body -->
            </div>
            </div>
          </div>
          <!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php require_once("inc/footer.php")?>